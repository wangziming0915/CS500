class Chimney:
    def __init__(self) -> None:
        pass

class Kitchen:
    def __init__(self) -> None:
        self.Chimney = Chimney()